﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int[,] matrix = {
            {3, 2, 1},
            {6, 5, 4},
            {9, 8, 7}
        };

        Console.WriteLine("До сортировки:");
        PrintMatrix(matrix);

        SortColumns(matrix);

        Console.WriteLine("После сортировки:");
        PrintMatrix(matrix);
    }

    static void SortColumns(int[,] matrix)
    {
        int rows = matrix.GetLength(0);
        int cols = matrix.GetLength(1);

        for (int c = 0; c < cols; c++)
        {
            for (int i = 0; i < rows - 1; i++)
            {
                for (int j = i + 1; j < rows; j++)
                {
                    if (matrix[j, c] > matrix[i, c])
                    {
                        int temp = matrix[i, c];
                        matrix[i, c] = matrix[j, c];
                        matrix[j, c] = temp;
                    }
                }
            }
        }
    }

    static void PrintMatrix(int[,] matrix)
    {
        int rows = matrix.GetLength(0);
        int cols = matrix.GetLength(1);

        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                Console.Write(matrix[i, j] + " ");
            }
            Console.WriteLine();
        }
    }
}