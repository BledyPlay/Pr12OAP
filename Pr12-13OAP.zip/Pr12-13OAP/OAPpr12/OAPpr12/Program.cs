﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double x = 2;
        double y = 3;
        double z = 4;
        Console.WriteLine($"Method with function: {CalculateWithFunction(x, y, z)}");
        CalculateWithProcedure(x, y, z, out double result);
        Console.WriteLine($"Method with procedure: {result}");
        Console.WriteLine("Press any key to exit...");
        Console.ReadKey();
    }

    static double CalculateWithFunction(double x, double y, double z)
    {
        return (Min(x, Math.Exp(y), z) + Min(y, Math.Pow(2, x), Math.Pow(z, 2))) / Min(z, 20, 3 * x);
    }

    static void CalculateWithProcedure(double x, double y, double z, out double result)
    {
        double numerator = Min(x, Math.Exp(y), z) + Min(y, Math.Pow(2, x), Math.Pow(z, 2));
        double denominator = Min(z, 20, 3 * x);
        result = numerator / denominator;
    }

    static double Min(double a, double b)
    {
        return Math.Min(a, b);
    }

    static double Min(double a, double b, double c)
    {
        return Math.Min(Math.Min(a, b), c);
    }
}